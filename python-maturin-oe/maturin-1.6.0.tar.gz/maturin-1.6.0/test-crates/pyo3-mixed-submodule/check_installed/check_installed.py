#!/usr/bin/env python3

import pyo3_mixed_submodule

assert pyo3_mixed_submodule.get_42() == 42

print("SUCCESS")
