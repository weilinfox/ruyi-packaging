A crate where pyo3 is an optional feature
