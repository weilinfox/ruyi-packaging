# pyo3-mixed src layout

A package for testing maturin with a src layout mixed pyo3/python project.

## Usage

```bash
pip install .
```

```python
import pyo3_mixed_src
assert pyo3_mixed_src.get_42() == 42
```
