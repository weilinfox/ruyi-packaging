pub fn foo() -> &'static str {
    "foo"
}
