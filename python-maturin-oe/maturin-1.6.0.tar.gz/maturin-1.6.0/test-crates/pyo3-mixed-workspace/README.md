# pyo3-mixed src layout

A package for testing maturin with a nested workspace.

## Usage

```bash
pip install .
```

```python
import pyo3_mixed_workspace
assert pyo3_mixed_workspace.get_42() == 42
```
