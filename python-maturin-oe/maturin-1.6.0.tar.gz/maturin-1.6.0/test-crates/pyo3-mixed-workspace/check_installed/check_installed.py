#!/usr/bin/env python3

import pyo3_mixed_workspace as pyo3_mixed

assert pyo3_mixed.get_42() == 42

print("SUCCESS")
