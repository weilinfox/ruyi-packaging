#!/usr/bin/env python3

import pyo3_mixed_include_exclude

assert pyo3_mixed_include_exclude.get_42() == 42

print("SUCCESS")
