#!/usr/bin/env python3

import uniffi_mixed

assert uniffi_mixed.add(1, 2) == 3

print("SUCCESS")
