fn main() {
    uniffi::generate_scaffolding("./src/math.udl").unwrap();
}
