import uniffi_mixed


def test_add():
    assert uniffi_mixed.add(1, 2) == 3
