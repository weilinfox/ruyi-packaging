pub fn bar() -> &'static str {
    "bar"
}
