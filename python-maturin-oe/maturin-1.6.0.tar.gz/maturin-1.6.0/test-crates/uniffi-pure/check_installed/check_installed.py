#!/usr/bin/env python3

import uniffi_pure

assert uniffi_pure.add(1, 2) == 3

print("SUCCESS")
