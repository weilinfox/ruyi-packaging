 * `py.exe`: Mock for the windows python launcher we can insert in path
