**********************************************************************
Packing
**********************************************************************

.. autoclass:: pygit2.Repository
   :members: pack
   :noindex:


The PackBuilder
================

.. autoclass:: pygit2.PackBuilder
   :members:
   :undoc-members:
   :special-members: __len__
