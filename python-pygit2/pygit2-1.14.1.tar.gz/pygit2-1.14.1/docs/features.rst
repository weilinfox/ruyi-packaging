**********************************************************************
Feature detection
**********************************************************************

.. py:data:: pygit2.features

   This variable contains a combination of `enums.Feature` flags,
   indicating which features a particular build of libgit2 supports.
